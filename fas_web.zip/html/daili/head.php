<?php
	require('system.php');
?>
<!DOCTYPE html>
<html lang="cn" >
<head>
<meta charset="utf-8" />
<title>叮咚流量卫士 云库系统</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="/css/bootstrap.min.css" />
<script src="/css/jquery.min.js"></script>
<script src="/css/bootstrap.min.js"></script>
<link rel="stylesheet" href="/css/font-awesome.min.css">
</head>
<body>
<style type="text/css">
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	font-family: "Microsoft Yahei","Hiragino Sans GB","Helvetica Neue",Helvetica,tahoma,arial,Verdana,sans-serif,"WenQuanYi Micro Hei","\5B8B\4F53";
}
*{
	padding:0px;
	list-style:none;
}


 .container{
	
}
.content-main{
	background:#fff;
	padding:20px 20px;

}
.btn{
	border-radius: 0px;
}
.tip{
	padding:15px;
	margin:10px;
	background:#fff;
}
.tip-success{
	background:
}
.box{
	background:#fff;
	padding:20px;
	
}
</style>
